package com.gridweaver.backend.controller;

import com.gridweaver.backend.model.IoTDevice;
import com.gridweaver.backend.state.BatteryState;
import com.gridweaver.backend.state.BatteryStateMachine;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/devices")
public class DeviceController {

    private final BatteryStateMachine stateMachine;
    private final SimpMessagingTemplate messagingTemplate;

    public DeviceController(
            BatteryStateMachine stateMachine,
            SimpMessagingTemplate messagingTemplate) {

        this.stateMachine = stateMachine;
        this.messagingTemplate = messagingTemplate;
    }

    @GetMapping
    public List<IoTDevice> getDevices() {

        List<IoTDevice> devices = createDevices();

        messagingTemplate.convertAndSend(
                "/topic/devices",
                devices
        );

        return devices;
    }

    @GetMapping("/{id}")
    public IoTDevice getDevice(@PathVariable String id) {

        BatteryState state =
                stateMachine.determineState(85, 75);

        return new IoTDevice(
                id,
                "Hyderabad",
                70.5,
                75,
                state.name()
        );
    }

    @PostMapping("/telemetry")
    public String receiveTelemetry(@RequestBody IoTDevice device) {

        double gridLoad = 85;

        BatteryState state =
                stateMachine.determineState(
                        gridLoad,
                        device.getBatteryLevel()
                );

        System.out.println(
                "Received telemetry from " +
                device.getDeviceId() +
                " | Grid Load: " +
                gridLoad +
                "% | Battery: " +
                device.getBatteryLevel() +
                "% | State: " +
                state
        );

        List<IoTDevice> devices = createDevices();

        messagingTemplate.convertAndSend(
                "/topic/devices",
                devices
        );

        return "Telemetry received from "
                + device.getDeviceId()
                + " | New State: "
                + state;
    }

    private List<IoTDevice> createDevices() {

        List<IoTDevice> devices = new ArrayList<>();

        double gridLoad1 = 85;
        double gridLoad2 = 45;
        double gridLoad3 = 65;

        BatteryState state1 =
                stateMachine.determineState(gridLoad1, 80);

        BatteryState state2 =
                stateMachine.determineState(gridLoad2, 65);

        BatteryState state3 =
                stateMachine.determineState(gridLoad3, 25);

        devices.add(new IoTDevice(
                "SOLAR-001",
                "Hyderabad",
                75.5,
                80,
                state1.name()
        ));

        devices.add(new IoTDevice(
                "BATTERY-002",
                "Secunderabad",
                45.2,
                65,
                state2.name()
        ));

        devices.add(new IoTDevice(
                "SOLAR-003",
                "Quthbullapur",
                20.4,
                25,
                state3.name()
        ));

        return devices;
    }
}