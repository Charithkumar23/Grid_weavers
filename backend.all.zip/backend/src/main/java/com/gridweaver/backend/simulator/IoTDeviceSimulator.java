package com.gridweaver.backend.simulator;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class IoTDeviceSimulator {

    public static void main(String[] args) {

        ExecutorService executor =
                Executors.newVirtualThreadPerTaskExecutor();

        HttpClient client = HttpClient.newHttpClient();

        Semaphore limit = new Semaphore(100);

        for (int i = 1; i <= 10000; i++) {

            int deviceId = i;

            executor.submit(() -> {

                try {

                    limit.acquire();

                    double solarPower = 20 + Math.random() * 80;
                    double batteryLevel = Math.random() * 100;

                    String state;

                    if (batteryLevel > 70) {
                        state = "CHARGING";
                    } else if (batteryLevel < 30) {
                        state = "DISCHARGING";
                    } else {
                        state = "IDLE";
                    }

                    String json = """
                            {
                                "deviceId": "DEVICE-%05d",
                                "location": "Hyderabad",
                                "solarPower": %.2f,
                                "batteryLevel": %.2f,
                                "state": "%s"
                            }
                            """.formatted(
                            deviceId,
                            solarPower,
                            batteryLevel,
                            state
                    );

                    HttpRequest request = HttpRequest.newBuilder()
                            .uri(URI.create(
                                    "http://localhost:8080/api/devices/telemetry"
                            ))
                            .header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(json))
                            .build();

                    HttpResponse<String> response =
                            client.send(
                                    request,
                                    HttpResponse.BodyHandlers.ofString()
                            );

                    System.out.println(
                            "Device " + deviceId +
                            " -> HTTP " + response.statusCode() +
                            " -> " + response.body()
                    );

                } catch (Exception e) {

                    System.out.println(
                            "Device " + deviceId +
                            " failed: " + e
                    );

                } finally {

                    limit.release();
                }
            });
        }

        executor.close();

        System.out.println("10,000 IoT telemetry requests completed.");
    }
}