package com.gridweaver.backend.state;

import org.springframework.stereotype.Service;

@Service
public class BatteryStateMachine {

    public BatteryState determineState(double gridLoad, double batteryLevel) {

        if (batteryLevel < 10) {
            return BatteryState.FAULT;
        }

        if (gridLoad > 80) {
            return BatteryState.DISCHARGING;
        }

        if (gridLoad < 50) {
            return BatteryState.CHARGING;
        }

        return BatteryState.IDLE;
    }
}
