package com.gridweaver.backend.model;

public class IoTDevice {

    private String deviceId;
    private String location;
    private double solarPower;
    private double batteryLevel;
    private String state;

    public IoTDevice() {
    }

    public IoTDevice(String deviceId, String location, double solarPower,
                     double batteryLevel, String state) {
        this.deviceId = deviceId;
        this.location = location;
        this.solarPower = solarPower;
        this.batteryLevel = batteryLevel;
        this.state = state;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getSolarPower() {
        return solarPower;
    }

    public void setSolarPower(double solarPower) {
        this.solarPower = solarPower;
    }

    public double getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(double batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}