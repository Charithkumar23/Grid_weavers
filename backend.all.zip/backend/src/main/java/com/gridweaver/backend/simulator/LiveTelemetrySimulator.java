package com.gridweaver.backend.simulator;

import com.gridweaver.backend.model.IoTDevice;
import com.gridweaver.backend.state.BatteryState;
import com.gridweaver.backend.state.BatteryStateMachine;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class LiveTelemetrySimulator {

    private static final int DEVICE_COUNT = 10_000;
    private static final int DASHBOARD_DEVICE_COUNT = 20;

    private final BatteryStateMachine stateMachine;
    private final SimpMessagingTemplate messagingTemplate;
    private final Random random = new Random();

    public LiveTelemetrySimulator(
            BatteryStateMachine stateMachine,
            SimpMessagingTemplate messagingTemplate) {

        this.stateMachine = stateMachine;
        this.messagingTemplate = messagingTemplate;
    }

    @Scheduled(fixedRate = 5000)
    public void generateTelemetry() {

        long startTime = System.currentTimeMillis();

        List<IoTDevice> dashboardDevices =
                new ArrayList<>(DASHBOARD_DEVICE_COUNT);

        int charging = 0;
        int discharging = 0;
        int idle = 0;
        int fault = 0;

        double totalSolarPower = 0;
        double totalBattery = 0;

        try (ExecutorService executor =
                     Executors.newVirtualThreadPerTaskExecutor()) {

            List<java.util.concurrent.Future<IoTDevice>> tasks =
                    new ArrayList<>(DEVICE_COUNT);

            for (int i = 1; i <= DEVICE_COUNT; i++) {

                final int deviceNumber = i;

                tasks.add(
                        executor.submit(
                                () -> generateDevice(deviceNumber)
                        )
                );
            }

            for (int i = 0; i < tasks.size(); i++) {

                try {
                    IoTDevice device = tasks.get(i).get();

                    totalSolarPower += device.getSolarPower();
                    totalBattery += device.getBatteryLevel();

                    switch (device.getState()) {
                        case "CHARGING" -> charging++;
                        case "DISCHARGING" -> discharging++;
                        case "FAULT" -> fault++;
                        default -> idle++;
                    }

                    if (i < DASHBOARD_DEVICE_COUNT) {
                        dashboardDevices.add(device);
                    }

                } catch (Exception e) {

                    System.err.println(
                            "Device generation error: "
                                    + e.getMessage()
                    );
                }
            }
        }

        double averageBattery =
                totalBattery / DEVICE_COUNT;

        /*
         * Send only a small dashboard payload.
         * The 10,000 devices are still processed,
         * but we do not send all 10,000 objects
         * through the WebSocket.
         */
        DashboardTelemetry telemetry =
                new DashboardTelemetry(
                        DEVICE_COUNT,
                        Math.round(totalSolarPower * 10.0) / 10.0,
                        Math.round(averageBattery * 10.0) / 10.0,
                        charging,
                        discharging,
                        idle,
                        fault,
                        dashboardDevices
                );

        messagingTemplate.convertAndSend(
                "/topic/devices",
                telemetry
        );

        long duration =
                System.currentTimeMillis() - startTime;

        System.out.println(
                "10,000 VIRTUAL DEVICES PROCESSED | "
                        + "Charging: " + charging
                        + " | Discharging: " + discharging
                        + " | Idle: " + idle
                        + " | Fault: " + fault
                        + " | Time: " + duration + " ms"
        );
    }

    private IoTDevice generateDevice(int deviceNumber) {

        String deviceId =
                String.format(
                        "IOT-%05d",
                        deviceNumber
                );

        String[] locations = {
                "Hyderabad",
                "Secunderabad",
                "Quthbullapur",
                "Kukatpally",
                "Miyapur",
                "Bachupally",
                "Suchitra",
                "Jeedimetla",
                "Kompally",
                "Medchal"
        };

        String location =
                locations[
                        (deviceNumber - 1)
                                % locations.length
                ];

        double solarPower =
                5 + random.nextDouble() * 95;

        double gridLoad =
                20 + random.nextDouble() * 75;

        double batteryLevel =
                5 + random.nextDouble() * 90;

        BatteryState state =
                stateMachine.determineState(
                        gridLoad,
                        batteryLevel
                );

        return new IoTDevice(
                deviceId,
                location,
                Math.round(solarPower * 10.0) / 10.0,
                Math.round(batteryLevel * 10.0) / 10.0,
                state.name()
        );
    }

    public record DashboardTelemetry(
            int totalDevices,
            double totalSolarPower,
            double averageBattery,
            int charging,
            int discharging,
            int idle,
            int fault,
            List<IoTDevice> devices
    ) {
    }
}