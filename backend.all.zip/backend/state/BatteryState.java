package com.gridweaver.backend.state;
public enum BatteryState {
    CHARGING,
    DISCHARGING,
    IDLE,
    FAULT
}