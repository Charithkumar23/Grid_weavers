package com.gridweaver.backend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class TelemetryWebSocketService {

    private final SimpMessagingTemplate messagingTemplate;

    @Autowired
    public TelemetryWebSocketService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @KafkaListener(
            topics = "gridweaver-telemetry",
            groupId = "gridweaver-dashboard"
    )
    public void receiveTelemetry(String telemetry) {

        System.out.println("Dashboard Telemetry: " + telemetry);

        messagingTemplate.convertAndSend(
                "/topic/telemetry",
                telemetry
        );
    }
}
