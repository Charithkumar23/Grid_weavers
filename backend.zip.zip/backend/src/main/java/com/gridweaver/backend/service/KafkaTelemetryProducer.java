package com.gridweaver.backend.service;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaTelemetryProducer {

    private static final String TOPIC = "gridweaver-telemetry";

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public KafkaTelemetryProducer(
            KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendTelemetry(Object telemetry) {
        kafkaTemplate.send(TOPIC, telemetry);
    }
}